set_db init_lib_search_path /home/install/FOUNDRY/digital/90nm/dig/lib
set_db init_hdl_search_path /home/student/Desktop/22BEC1250/work
read_libs slow.lib
read_hdl srflop.v
elaborate
read_sdc srflop_constraints.g
set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium
syn_generic
syn_map
syn_opt
write_hdl > srflop_netlist.v
write_sdc > srflop_constrainsts.sdc

#write_sdc -timescale ns -nonegchecks -recrem split -edgs check_edge -setuphold split > delays.sdf
