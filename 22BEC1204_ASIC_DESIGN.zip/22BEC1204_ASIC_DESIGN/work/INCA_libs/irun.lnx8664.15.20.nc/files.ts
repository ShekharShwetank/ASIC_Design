1752463472 /home/student/Desktop/22BEC1204_ASIC_DESIGN/work/cds.lib
1752463573 /home/student/Desktop/22BEC1204_ASIC_DESIGN/work/hdl.var
1753067330 /home/student/Desktop/22BEC1204_ASIC_DESIGN/work/sync_HA_tb.v
