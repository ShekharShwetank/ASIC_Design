1752463999 /home/student/Desktop/22BEC1204_ASIC_DESIGN/work/four_bitcounter.v
1752464209 /home/student/Desktop/22BEC1204_ASIC_DESIGN/work/four_bitcounter_tb.v
